import logging
from pathlib import Path
from urllib.parse import quote

logger = logging.getLogger(__name__)


def loadProxies(path: str) -> list[dict]:
    """
    Load proxies from a txt file.
    Supported formats:
      ip:port
      host:port:username:password  (password may contain colons)
    """
    proxies = []
    file = Path(path)
    if not file.exists():
        logger.warning(f"Proxy file not found: {path}")
        return proxies

    with open(file) as f:
        for lineNum, raw in enumerate(f, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(":", 3)
            if len(parts) == 2:
                server, port = parts
                proxies.append({"server": f"http://{server}:{port}"})
            elif len(parts) == 4:
                server, port, username, password = parts
                # Encode credentials into the URL — more reliable with Playwright
                u = quote(username, safe="")
                pw = quote(password, safe="")
                proxies.append({
                    "server": f"http://{u}:{pw}@{server}:{port}",
                })
            else:
                logger.warning(f"Skipping malformed proxy on line {lineNum}: {line!r}")
                continue

    logger.info(f"Loaded {len(proxies)} proxies from {path}")
    return proxies


def getProxy(proxies: list[dict], index: int) -> dict | None:
    if not proxies:
        return None
    return proxies[index % len(proxies)]