import json
import random
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def loadPreferences(path: str = "preference.json") -> list[dict]:
    """Load all preferences from preference.json."""
    file = Path(path)
    if not file.exists():
        raise FileNotFoundError(f"Preference file not found: {path}")
    with open(file, encoding="utf-8") as f:
        data = json.load(f)
    logger.info(f"Loaded {len(data)} preferences from {path}")
    return data


def pickRandom(preferences: list[dict], lang: str | None = None) -> tuple[str, str, list[str]]:
    """
    Pick a random preference and a random language that has content.
    If lang is specified, only use entries that have that language.
    Returns (slug, language, lines).
    """
    pref = random.choice(preferences)
    available = {
        l: texts
        for l, texts in pref["texts"].items()
        if texts
    }

    if lang:
        if lang in available and available[lang]:
            lines = [line for line in available[lang] if line.strip()]
            return pref["slug"], lang, lines
        # this preference doesn't have the requested lang — try another
        return pickRandom(preferences, lang)

    if not available:
        return pickRandom(preferences)

    language = random.choice(list(available.keys()))
    lines = [line for line in available[language] if line.strip()]
    return pref["slug"], language, lines
