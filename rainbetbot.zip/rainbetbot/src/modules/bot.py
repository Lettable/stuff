import asyncio
import logging
import random
import string

from patchright.async_api import async_playwright, Frame

from src.modules.preferences import pickRandom

logger = logging.getLogger(__name__)

DOMAINS = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "icloud.com", "protonmail.com"]

TARGET_URL = "https://rainbet.com"


def randomEmail() -> str:
    length = random.randint(6, 14)
    name = "".join(random.choices(string.ascii_lowercase + string.digits, k=length))
    if random.random() > 0.5 and length > 4:
        pos = random.randint(2, length - 2)
        sep = random.choice([".", "_"])
        name = name[:pos] + sep + name[pos:]
    domain = random.choice(DOMAINS)
    return f"{name}@{domain}"


async def typeLine(textarea, line: str) -> None:
    words = line.split()
    for i, word in enumerate(words):
        if i > 0:
            await textarea.type(" ", delay=0)
        await textarea.type(word, delay=40)
        await asyncio.sleep(1)


async def handleCloudflareTurnstile(page, tag: str) -> bool:
    cfSelector = 'iframe[title="Widget containing a Cloudflare security challenge"]'
    try:
        await page.wait_for_selector(cfSelector, timeout=8_000)
    except Exception:
        return False

    logger.info(f"{tag} Cloudflare challenge detected — waiting for checkbox...")

    try:
        cfFrame = page.frame_locator(cfSelector)
        checkbox = cfFrame.locator('input[type="checkbox"]')
        await checkbox.wait_for(state="visible", timeout=30_000)
        await checkbox.click()
        logger.info(f"{tag} Cloudflare checkbox clicked")
    except Exception as e:
        logger.warning(f"{tag} Could not click CF checkbox ({e}) — proceeding anyway")
        return False

    try:
        await page.wait_for_selector(cfSelector, state="hidden", timeout=20_000)
        logger.info(f"{tag} Cloudflare challenge cleared")
    except Exception:
        logger.warning(f"{tag} CF iframe did not disappear — proceeding anyway")

    return True


async def handleEmailCollector(frame: Frame, tag: str) -> bool:
    emailInput = frame.locator('input[aria-label="Enter your email"]')
    try:
        await emailInput.wait_for(state="visible", timeout=6_000)
    except Exception:
        return False

    email = randomEmail()
    logger.info(f"{tag} Email collector detected — submitting {email!r}")

    await emailInput.click()
    await asyncio.sleep(0.3)
    await emailInput.type(email, delay=40)
    await asyncio.sleep(0.5)

    submitBtn = frame.locator('button[aria-label="Submit"]')
    await submitBtn.click()
    logger.info(f"{tag} Email submitted")
    await asyncio.sleep(1)
    return True


async def waitForReply(
    frame: Frame,
    countBeforeSend: int,
    timeoutS: int,
) -> bool:
    loop = asyncio.get_event_loop()
    deadline = loop.time() + timeoutS
    while loop.time() < deadline:
        try:
            count = await frame.locator('[data-testid="conversation-part"]').count()
            if count >= countBeforeSend + 2:
                return True
        except Exception:
            pass
        await asyncio.sleep(1)
    return False


async def runSession(
    sessionId: int,
    proxy: dict | None,
    preferences: list[dict],
    timeoutMinutes: int,
    idleMinutes: int,
    typingMin: int,
    typingMax: int,
    lang: str | None = None,
) -> None:
    tag = f"[session-{sessionId}]"
    logger.info(f"{tag} Starting | reply delay {typingMin}-{typingMax}s")

    runCount = 0

    while True:
        runCount += 1
        logger.info(f"{tag} ── Run #{runCount} ──────────────────────────────")

        async with async_playwright() as p:
            # Pass proxy at launch level AND context level for maximum compatibility
            launchArgs: dict = {
                "headless": False,
                "args": ["--no-sandbox", "--disable-blink-features=AutomationControlled"],
            }
            if proxy:
                launchArgs["proxy"] = proxy
                logger.info(f"{tag} Using proxy: {proxy['server']}")

            browser = await p.chromium.launch(**launchArgs)

            contextArgs: dict = {"viewport": {"width": 1280, "height": 800}}
            if proxy:
                contextArgs["proxy"] = proxy

            context = await browser.new_context(**contextArgs)
            page = await context.new_page()

            try:
                logger.info(f"{tag} Navigating to {TARGET_URL}")
                await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=60_000)

                await handleCloudflareTurnstile(page, tag)

                logger.info(f"{tag} Waiting for support button...")
                supportBtn = page.locator('button[aria-label="Intercom"]')
                await supportBtn.wait_for(state="visible", timeout=60_000)
                await supportBtn.click()
                logger.info(f"{tag} Clicked support button")
                await asyncio.sleep(3)

                logger.info(f"{tag} Waiting for Intercom iframe...")
                await page.wait_for_selector(
                    'iframe[name="intercom-messenger-frame"]',
                    timeout=60_000,
                )
                await asyncio.sleep(2)

                frame: Frame | None = page.frame(name="intercom-messenger-frame")
                if frame is None:
                    raise RuntimeError("Intercom iframe not found")
                logger.info(f"{tag} Got Intercom frame")

                logger.info(f"{tag} Clicking Messages tab...")
                messagesTab = frame.locator('button#spaces-messages-tab')
                await messagesTab.wait_for(state="visible", timeout=60_000)
                await messagesTab.click()
                logger.info(f"{tag} Clicked Messages tab")
                await asyncio.sleep(1)

                logger.info(f"{tag} Looking for 'Send us a message'...")
                sendMsgBtn = frame.locator('button[data-testid="send-a-message-button"]')
                await sendMsgBtn.wait_for(state="visible", timeout=60_000)
                await sendMsgBtn.click()
                logger.info(f"{tag} Clicked 'Send us a message'")

                logger.info(f"{tag} Waiting for message textarea...")
                textarea = frame.locator('textarea[placeholder="Message\u2026"]')
                await textarea.wait_for(state="visible", timeout=60_000)
                logger.info(f"{tag} Textarea ready")

                slug, language, lines = pickRandom(preferences, lang)
                logger.info(f"{tag} Preference: {slug!r} | Lang: {language} | Lines: {len(lines)}")

                sendBtn = frame.locator('button[aria-label="Send a message\u2026"]')
                timeoutS = timeoutMinutes * 60

                for idx, line in enumerate(lines):
                    logger.info(f"{tag} Line {idx + 1}/{len(lines)}: {line!r}")

                    countBefore = await frame.locator('[data-testid="conversation-part"]').count()

                    await textarea.click()
                    await typeLine(textarea, line)
                    await sendBtn.click()
                    logger.info(f"{tag} Sent. Waiting for reply (timeout={timeoutMinutes}m)...")

                    if idx == 0:
                        await handleEmailCollector(frame, tag)

                    gotReply = await waitForReply(frame, countBefore, timeoutS)
                    if gotReply:
                        logger.info(f"{tag} Reply received")
                    else:
                        logger.warning(f"{tag} No reply within {timeoutMinutes}m — moving to next line")

                    if idx < len(lines) - 1:
                        delay = random.randint(typingMin, typingMax)
                        logger.info(f"{tag} Waiting {delay}s before next message...")
                        await asyncio.sleep(delay)

                logger.info(f"{tag} All {len(lines)} lines sent. Idling for {idleMinutes}m...")
                await asyncio.sleep(idleMinutes * 60)

                logger.info(f"{tag} Idle complete. Closing browser — restarting loop...")
                await browser.close()

            except asyncio.CancelledError:
                logger.info(f"{tag} Session cancelled — closing browser")
                try:
                    await browser.close()
                except Exception:
                    pass
                return  # exit the while loop cleanly

            except Exception as exc:
                logger.error(f"{tag} Unexpected error: {exc}", exc_info=True)
                logger.info(f"{tag} Closing browser and restarting in 5s...")
                try:
                    await browser.close()
                except Exception:
                    pass
                await asyncio.sleep(5)
                # continue → next iteration of while True