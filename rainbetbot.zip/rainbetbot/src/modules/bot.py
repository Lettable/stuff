import asyncio
import logging
import random
import string

from patchright.async_api import async_playwright, Frame

from src.modules.preferences import pickRandom

logger = logging.getLogger(__name__)

DOMAINS = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "icloud.com", "protonmail.com"]


def randomEmail() -> str:
    """Generate a plausible random email address."""
    length = random.randint(6, 14)
    name = "".join(random.choices(string.ascii_lowercase + string.digits, k=length))
    # occasionally add a dot or underscore in the middle
    if random.random() > 0.5 and length > 4:
        pos = random.randint(2, length - 2)
        sep = random.choice([".", "_"])
        name = name[:pos] + sep + name[pos:]
    domain = random.choice(DOMAINS)
    return f"{name}@{domain}"

TARGET_URL = "https://rainbet.com"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def typeLine(textarea, line: str) -> None:
    """Type a line into the textarea one word per second."""
    words = line.split()
    for i, word in enumerate(words):
        if i > 0:
            await textarea.type(" ", delay=0)
        await textarea.type(word, delay=40)
        await asyncio.sleep(1)


async def handleCloudflareTurnstile(page, tag: str) -> bool:
    """
    If a Cloudflare Turnstile challenge iframe is present, click its checkbox.
    Returns True if the challenge was found and handled, False if not present.
    Never raises — any internal failure is caught, logged, and the session continues.
    """
    cfSelector = 'iframe[title="Widget containing a Cloudflare security challenge"]'

    # Step 1: check if the CF iframe even appears (short window)
    try:
        await page.wait_for_selector(cfSelector, timeout=8_000)
    except Exception:
        return False  # no CF challenge — continue normally

    logger.info(f"{tag} Cloudflare challenge detected — waiting for checkbox...")

    # Step 2: wait for the checkbox inside the CF iframe (give it plenty of time)
    try:
        cfFrame = page.frame_locator(cfSelector)
        checkbox = cfFrame.locator('input[type="checkbox"]')
        await checkbox.wait_for(state="visible", timeout=30_000)
        await checkbox.click()
        logger.info(f"{tag} Cloudflare checkbox clicked")
    except Exception as e:
        logger.warning(f"{tag} Could not click CF checkbox ({e}) — proceeding anyway")
        return False

    # Step 3: wait for the CF iframe to disappear (challenge passed)
    try:
        await page.wait_for_selector(cfSelector, state="hidden", timeout=20_000)
        logger.info(f"{tag} Cloudflare challenge cleared")
    except Exception:
        logger.warning(f"{tag} CF iframe did not disappear — proceeding anyway")

    return True


async def handleEmailCollector(frame: Frame, tag: str) -> bool:
    """
    If Rainbet's email-collector prompt appears after the first message,
    fill in a random email and submit it.
    Returns True if handled, False if not present.
    """
    emailInput = frame.locator('input[type="email"][placeholder="email@example.com"]')
    try:
        await emailInput.wait_for(state="visible", timeout=6_000)
    except Exception:
        return False  # prompt didn't appear

    email = randomEmail()
    logger.info(f"{tag} Email collector detected — submitting {email!r}")
    await emailInput.fill(email)
    await asyncio.sleep(0.5)

    submitBtn = frame.locator('button[aria-label="Submit"]')
    await submitBtn.click()
    logger.info(f"{tag} Email submitted")
    await asyncio.sleep(1)
    return True


async def waitForReply(
    frame: Frame,
    countBeforeSend: int,
    timeoutS: int,
) -> bool:
    """
    Wait until an agent reply arrives.

    After we click send:
      countBeforeSend + 1  → our own message appeared
      countBeforeSend + 2  → agent replied

    Returns True if a reply was received within timeout, False otherwise.
    """
    loop = asyncio.get_event_loop()
    deadline = loop.time() + timeoutS
    while loop.time() < deadline:
        try:
            count = await frame.locator('[data-testid="conversation-part"]').count()
            if count >= countBeforeSend + 2:
                return True
        except Exception:
            pass
        await asyncio.sleep(1)
    return False


# ---------------------------------------------------------------------------
# Main session
# ---------------------------------------------------------------------------

async def runSession(
    sessionId: int,
    proxy: dict | None,
    preferences: list[dict],
    timeoutMinutes: int,
    idleMinutes: int,
    typingMin: int,
    typingMax: int,
    lang: str | None = None,
) -> None:
    tag = f"[session-{sessionId}]"
    logger.info(f"{tag} Starting | reply delay {typingMin}-{typingMax}s")

    async with async_playwright() as p:
        launchArgs = {
            "headless": False,
            "args": ["--no-sandbox", "--disable-blink-features=AutomationControlled"],
        }
        if proxy:
            launchArgs["proxy"] = proxy
            logger.info(f"{tag} Using proxy: {proxy['server']}")

        browser = await p.chromium.launch(**launchArgs)
        context = await browser.new_context(
            viewport={"width": 1280, "height": 800},
        )
        page = await context.new_page()

        try:
            # ----------------------------------------------------------------
            # 1. Navigate to Rainbet
            # ----------------------------------------------------------------
            logger.info(f"{tag} Navigating to {TARGET_URL}")
            await page.goto(TARGET_URL, wait_until="domcontentloaded", timeout=60_000)

            # ----------------------------------------------------------------
            # 2. Handle Cloudflare Turnstile challenge (if present)
            # ----------------------------------------------------------------
            await handleCloudflareTurnstile(page, tag)

            # ----------------------------------------------------------------
            # 3. Wait for & click the Rainbet support button
            # ----------------------------------------------------------------
            logger.info(f"{tag} Waiting for Rainbet support button...")
            supportBtn = page.locator('button[aria-label="Intercom"]')
            await supportBtn.wait_for(state="visible", timeout=60_000)
            await supportBtn.click()
            logger.info(f"{tag} Clicked support button")
            await asyncio.sleep(3)  # let the chat widget finish opening

            # ----------------------------------------------------------------
            # 4. Wait for Intercom iframe
            # ----------------------------------------------------------------
            logger.info(f"{tag} Waiting for Intercom iframe...")
            await page.wait_for_selector(
                'iframe[name="intercom-messenger-frame"]',
                timeout=60_000,
            )
            await asyncio.sleep(2)  # let iframe fully render its content

            frame: Frame | None = page.frame(name="intercom-messenger-frame")
            if frame is None:
                raise RuntimeError("Intercom iframe not found")
            logger.info(f"{tag} Got Intercom frame")

            # ----------------------------------------------------------------
            # 5. Click the "Messages" tab
            # ----------------------------------------------------------------
            logger.info(f"{tag} Clicking Messages tab...")
            messagesTab = frame.locator('button#spaces-messages-tab')
            await messagesTab.wait_for(state="visible", timeout=60_000)
            await messagesTab.click()
            logger.info(f"{tag} Clicked Messages tab")
            await asyncio.sleep(1)

            # ----------------------------------------------------------------
            # 6. Click "Send us a message"
            # ----------------------------------------------------------------
            logger.info(f"{tag} Looking for 'Send us a message'...")
            sendMsgBtn = frame.locator('button[data-testid="send-a-message-button"]')
            await sendMsgBtn.wait_for(state="visible", timeout=60_000)
            await sendMsgBtn.click()
            logger.info(f"{tag} Clicked 'Send us a message'")

            # ----------------------------------------------------------------
            # 7. Wait for textarea
            # ----------------------------------------------------------------
            logger.info(f"{tag} Waiting for message textarea...")
            textarea = frame.locator('textarea[placeholder="Message…"]')
            await textarea.wait_for(state="visible", timeout=60_000)
            logger.info(f"{tag} Textarea ready")

            # ----------------------------------------------------------------
            # 8. Pick random preference + language
            # ----------------------------------------------------------------
            slug, language, lines = pickRandom(preferences, lang)
            logger.info(
                f"{tag} Preference: {slug!r} | Lang: {language} | Lines: {len(lines)}"
            )

            sendBtn = frame.locator('button[aria-label="Send a message…"]')
            timeoutS = timeoutMinutes * 60

            # ----------------------------------------------------------------
            # 9. Send lines one by one, wait for reply between each
            # ----------------------------------------------------------------
            for idx, line in enumerate(lines):
                logger.info(f"{tag} Line {idx + 1}/{len(lines)}: {line!r}")

                countBefore = await frame.locator(
                    '[data-testid="conversation-part"]'
                ).count()

                await textarea.click()
                await typeLine(textarea, line)
                await sendBtn.click()
                logger.info(f"{tag} Sent. Waiting for reply (timeout={timeoutMinutes}m)...")

                # After the first message, Rainbet may ask for an email
                if idx == 0:
                    await handleEmailCollector(frame, tag)

                gotReply = await waitForReply(frame, countBefore, timeoutS)
                if gotReply:
                    logger.info(f"{tag} Reply received")
                else:
                    logger.warning(
                        f"{tag} No reply within {timeoutMinutes}m — moving to next line"
                    )

                # Wait random delay before typing next message (skip after last line)
                if idx < len(lines) - 1:
                    delay = random.randint(typingMin, typingMax)
                    logger.info(f"{tag} Waiting {delay}s before next message...")
                    await asyncio.sleep(delay)

            # ----------------------------------------------------------------
            # 10. Idle period then stay alive
            # ----------------------------------------------------------------
            logger.info(f"{tag} All {len(lines)} lines sent. Idling for {idleMinutes}m...")
            await asyncio.sleep(idleMinutes * 60)

            logger.info(f"{tag} Idle complete. Closing browser.")
            await browser.close()

        except asyncio.CancelledError:
            logger.info(f"{tag} Session cancelled")
        except Exception as exc:
            logger.error(f"{tag} Unexpected error: {exc}", exc_info=True)
            logger.info(f"{tag} Browser staying open for inspection. Press Ctrl+C to exit.")
            await asyncio.Event().wait()
