# rainbetbot

A browser automation bot that opens the Rainbet live support chat, picks a random conversation topic from a preference file, and sends messages one line at a time, waiting for an agent reply between each one, to simulate a real confused user keeping support busy.

---

## How It Works

The bot does the following steps automatically in a real headed browser:

1. Opens `https://rainbet.com`
2. Handles a **Cloudflare Turnstile** challenge if one appears (`input[type="checkbox"]` inside the CF iframe)
3. Waits for the **headset/Intercom support button** (`button[aria-label="Intercom"]`) and clicks it
4. Waits for the **Intercom chat iframe** (`intercom-messenger-frame`) to load
5. Clicks the **Messages tab** (`button#spaces-messages-tab`) inside the chat
6. Clicks **"Send us a message"** (`button[data-testid="send-a-message-button"]`)
7. Waits for the **message textarea** to appear
8. Picks a **random preference** and a **random language** from `preference.json`
9. Sends each line of that preference one by one:
   - Types the line **one word per second** into the textarea
   - Clicks the **send button** (`button[aria-label="Send a message…"]`)
   - Waits for the **agent to reply** before continuing
   - Once a reply comes in, waits a **random delay** (your `--typing` range) to simulate a real person reading and thinking
   - Then types the next line
10. After all lines are sent, stays **idle** for `--idle` minutes
11. Closes the browser

---

## Project Structure

```
rainbetbot/
├── preference.json          # conversation topics & multilingual lines
├── requirements.txt
└── src/
    ├── __main__.py          # CLI entry point
    └── modules/
        ├── bot.py           # core automation logic
        ├── preferences.py   # loads & picks from preference.json
        └── proxy.py         # proxy loader/selector
```

---

## Installation

```bash
pip install -r requirements.txt
patchright install chromium
```

---

## Usage

```bash
# Single session, no proxy
python -m src

# 3 concurrent sessions with proxy list
python -m src --count 3 --proxy proxies.txt

# Custom timeouts and typing speed
python -m src --count 2 --timeout 5 --idle 10 --typing 5:15

# Custom preference file
python -m src --preferences my_prefs.json
```

---

## CLI Options

| Flag | Default | Description |
|---|---|---|
| `--proxy FILE` | none | Path to proxy list (format: `server:port:user:pass` per line) |
| `--count N` | `1` | Number of concurrent browser sessions |
| `--timeout MIN` | `2` | Minutes to wait for agent reply before moving on |
| `--idle MIN` | `3` | Minutes to stay idle after all lines are sent |
| `--typing MIN:MAX` | `3:8` | Random delay range (seconds) between messages |
| `--preferences FILE` | `preference.json` | Path to your preference JSON file |

---

## preference.json Format

```json
[
  {
    "slug": "withdrawal-issue",
    "texts": {
      "en": [
        "Hi, I'm having trouble withdrawing my funds.",
        "It's been 3 days and still nothing.",
        "Can you check what's going on?"
      ],
      "es": [
        "Hola, tengo problemas para retirar mis fondos.",
        "Han pasado 3 días y no hay nada.",
        "¿Puedes revisar qué está pasando?"
      ]
    }
  }
]
```

Each session picks a random slug and a random available language from the file.
