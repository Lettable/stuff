import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def loadProxies(path: str) -> list[dict]:
    """
    Load proxies from a txt file.
    Supported formats:
      ip:port
      host:port:username:password  (password may contain colons)
    """
    proxies = []
    file = Path(path)
    if not file.exists():
        logger.warning(f"Proxy file not found: {path}")
        return proxies

    with open(file) as f:
        for lineNum, raw in enumerate(f, 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split(":", 3)
            if len(parts) == 2:
                server, port = parts
                proxies.append({"server": f"http://{server}:{port}"})
            elif len(parts) == 4:
                server, port, username, password = parts
                # Playwright requires credentials as separate fields, NOT embedded
                # in the URL — embedding them causes ERR_INVALID_AUTH_CREDENTIALS
                proxies.append({
                    "server": f"http://{server}:{port}",
                    "username": username,
                    "password": password,
                })
            else:
                logger.warning(f"Skipping malformed proxy on line {lineNum}: {line!r}")
                continue

    logger.info(f"Loaded {len(proxies)} proxies from {path}")
    return proxies


def getProxy(proxies: list[dict], index: int) -> dict | None:
    if not proxies:
        return None
    return proxies[index % len(proxies)]