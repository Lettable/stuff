# intercombot

A browser automation bot that opens the DuelBits live support chat, picks a random conversation topic from a preference file, and sends messages one line at a time, waiting for an agent reply between each one, to simulate a real confused user keeping support busy.

---

## How It Works

The bot does the following steps automatically in a real headed browser:

1. Opens `https://duelbits.com/en`
2. Waits for the **Live Support** button to appear and clicks it
3. Waits for the **Intercom chat iframe** to load
4. Clicks **"Send us a message"** inside the chat
5. Clicks the **"Agent"** button to route to a live agent
6. Waits for the **message textarea** to appear
7. Picks a **random preference** and a **random language** from `preference.json`
8. Sends each line of that preference one by one:
   - Types the line **one word per second** into the textarea
   - Clicks the **send button**
   - Waits for the **agent to reply** before continuing
   - Once a reply comes in, waits a **random delay** (your `--typing` range) to simulate a real person reading and thinking
   - Then types the next line
9. After all lines are sent, stays **idle** for `--idle` minutes
10. Leaves the browser **open indefinitely** — does not close anything

---

## Project Structure

```
intercombot/
├── preference.json          # All conversation topics and their lines
├── requirements.txt         # Python dependencies
├── proxies.txt              # Your proxy list (optional)
├── README.md
└── src/
    ├── __init__.py
    ├── __main__.py          # Entry point — CLI args + session launcher
    └── modules/
        ├── __init__.py
        ├── bot.py           # Full browser automation flow
        ├── proxy.py         # Proxy file loader
        └── preferences.py  # Preference loader and random picker
```

---

## Installation

```bash
pip install -r requirements.txt
patchright install chromium
```

`patchright` is a patched version of Playwright that bypasses bot detection and anti-automation fingerprinting.

---

## Running

```bash
python -m src [options]
```

### Examples

```bash
# Simplest run — 1 session, no proxy, all defaults
python -m src

# 3 sessions at once, each with a different proxy
python -m src --count 3 --proxy proxies.txt

# Set reply timeout to 5 minutes and idle for 2 minutes after finishing then closes
python -m src --timeout 5 --idle 2

# Typing delay: wait 3 to 8 seconds after each reply before sending next message
python -m src --typing 3:8

# Full example — 5 sessions, proxies, 4 min reply timeout, 3 min idle, 5-15s typing delay
python -m src --count 5 --proxy proxies.txt --timeout 4 --idle 3 --typing 5:15
```

---

## CLI Arguments

| Argument             | Default           | Description                                                                                                                                                                                                                                                                              |
| -------------------- | ----------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `--count N`          | `1`               | How many browser sessions to launch at the same time. Each session is independent — different proxy, different random preference, different browser window.                                                                                                                              |
| `--proxy FILE`       | none              | Path to your proxy list `.txt` file. If not given, the bot runs without a proxy. If you run `--count 5` with 5 proxies, each session gets a different one. If you have fewer proxies than sessions, they cycle round-robin.                                                              |
| `--timeout MIN`      | `2`               | How many **minutes** to wait for an agent reply after sending a message. If no reply comes in that time, the bot gives up waiting and moves on to the next line anyway.                                                                                                                  |
| `--idle MIN`         | `3`               | How many **minutes** the bot stays idle after it has sent all lines of a preference. After the idle period, the browser stays open and does nothing until you kill the process.                                                                                                          |
| `--typing MIN:MAX`   | `3:8`             | After receiving an agent reply, the bot waits a **random number of seconds** between `MIN` and `MAX` before it starts typing the next message. This makes the timing feel like a real human reading and thinking. Example: `--typing 3:19` waits anywhere from 3 to 19 seconds randomly. |
| `--preferences FILE` | `preference.json` | Path to your preference JSON file. Defaults to `preference.json` in the project root.                                                                                                                                                                                                    |

---

## Proxy File Format

One proxy per line in this exact format:

```
server:port:username:password
```

Example `proxies.txt`:

```
123.45.67.89:8080:myuser:mypass
98.76.54.32:3128:user2:pass2
11.22.33.44:1080:user3:pass3
```

Lines starting with `#` are treated as comments and skipped.

If a line is malformed (wrong number of colons, missing fields) it is skipped with a warning in the console.

---

## Preference File Format

`preference.json` is an array of preference objects. Each object looks like this:

```json
{
  "slug": "depositIssue",
  "texts": {
    "en": [
      "Hi",
      "yeah deposit issue",
      "idk what it is",
      "it just doesnt work",
      "tried again and same thing",
      "the balance didnt change",
      "its been like this for a while now",
      "do i need to do something else",
      "really confused about what to do"
    ],
    "zh": [
      "你好",
      "我有个问题想问一下",
      "好像是关于存款的",
      "也不太确定是什么原因"
    ]
  }
}
```

**Fields:**

- `slug` — a short identifier for the topic, used in logs so you can see which preference was picked
- `texts.en` — the English lines for this topic
- `texts.zh` — the Chinese lines for this topic

When the bot runs, it picks one preference at random, then picks one language at random from whichever languages have content. It then sends those lines one by one in order.

The lines are intentionally vague and non-precise — they describe a problem without giving clear details, which keeps the support agent engaged and confused about what exactly the issue is.

**How to add a new preference:**

Add a new object to the array in `preference.json` following the same format. The bot will automatically include it in the random pool.

---

## How Sessions Work with `--count`

When you use `--count 3`, three completely separate browser windows open at the same time. Each one:

- Gets its own proxy (from the proxy list, cycling if needed)
- Picks its own random preference and language independently
- Runs through its own conversation flow independently
- Has its own timing — they are not synced

All sessions run in parallel using Python's `asyncio`. The script does not exit until you press `Ctrl+C`.

---

## How the Reply Detection Works

After the bot sends a message, it counts how many `conversation-part` elements exist in the Intercom chat. It then watches for that number to increase by at least 2:

- `+1` means our own sent message appeared in the chat
- `+2` means the agent sent a reply

Once the count reaches `+2` or more, the bot considers a reply received and moves on to the next step (waiting the `--typing` delay, then sending the next line).

If the count never reaches `+2` within `--timeout` minutes, the bot logs a warning and moves on anyway so the conversation keeps going.

---

## Typing Behavior

Each line is typed **one word at a time** with a small character-level delay to simulate real keyboard input. After the last character of a word is typed, the bot waits 1 second before typing the next word.

After receiving a reply and before starting to type the next message, the bot additionally waits a random number of seconds controlled by `--typing MIN:MAX`. This gap simulates a real person reading the agent's reply before responding.

---

## What Happens at the End

After all lines in the selected preference are sent:

1. The bot waits for `--idle` minutes doing nothing (the chat stays open on screen)
2. After the idle period expires, the browser closes itself automatically
3. If you launched multiple sessions with `--count`, each one closes independently when its own idle timer runs out

---

## Logs

The console prints timestamped logs for every step:

```
12:34:01  INFO      Launching 2 session(s) | typing delay 3-19s...
12:34:01  INFO      [session-1] Starting | reply delay 3-19s
12:34:01  INFO      [session-2] Starting | reply delay 3-19s
12:34:03  INFO      [session-1] Navigating to https://duelbits.com/en
12:34:05  INFO      [session-1] Waiting for MenuSupportButton...
12:34:09  INFO      [session-1] Clicked Live Support button
12:34:11  INFO      [session-1] Got Intercom frame
12:34:13  INFO      [session-1] Clicked 'Send us a message'
12:34:15  INFO      [session-1] Clicked Agent button
12:34:16  INFO      [session-1] Preference: 'depositIssue' | Lang: zh | Lines: 12
12:34:16  INFO      [session-1] Line 1/12: '你好'
12:34:17  INFO      [session-1] Sent. Waiting for reply (timeout=2m)...
12:34:45  INFO      [session-1] Reply received
12:34:45  INFO      [session-1] Waiting 11s before next message...
```
