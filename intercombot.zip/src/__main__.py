import argparse
import asyncio
import logging

from src.modules.bot import runSession
from src.modules.proxy import loadProxies, getProxy
from src.modules.preferences import loadPreferences


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)


def parseTyping(value: str) -> tuple[int, int]:
    """Parse --typing min:max into a (min, max) int tuple."""
    try:
        parts = value.split(":")
        if len(parts) != 2:
            raise ValueError
        lo, hi = int(parts[0]), int(parts[1])
        if lo < 0 or hi < lo:
            raise ValueError
        return lo, hi
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"--typing must be in min:max format with min <= max, e.g. 3:19. Got: {value!r}"
        )


def parseArgs() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="intercombot — Intercom live support automation"
    )
    parser.add_argument(
        "--proxy",
        metavar="FILE",
        default=None,
        help="Path to proxy list txt file (server:port:username:password per line)",
    )
    parser.add_argument(
        "--count",
        type=int,
        default=1,
        metavar="N",
        help="Number of concurrent browser sessions to launch (default: 1)",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=2,
        metavar="MIN",
        help="Minutes to wait for an agent reply before moving to next line (default: 2)",
    )
    parser.add_argument(
        "--idle",
        type=int,
        default=3,
        metavar="MIN",
        help="Minutes to stay idle after all lines are sent (default: 3)",
    )
    parser.add_argument(
        "--typing",
        type=parseTyping,
        default=(3, 8),
        metavar="MIN:MAX",
        help="Random delay range in seconds to wait after receiving a reply before typing the next message (default: 3:8)",
    )
    parser.add_argument(
        "--preferences",
        metavar="FILE",
        default="preference.json",
        help="Path to preference.json (default: preference.json)",
    )
    return parser.parse_args()


async def main() -> None:
    args = parseArgs()

    proxies: list[dict] = []
    if args.proxy:
        proxies = loadProxies(args.proxy)
        if not proxies:
            logging.warning("Proxy file was given but no valid proxies were loaded — running without proxy")

    preferences = loadPreferences(args.preferences)

    typingMin, typingMax = args.typing

    tasks = [
        asyncio.create_task(
            runSession(
                sessionId=i + 1,
                proxy=getProxy(proxies, i),
                preferences=preferences,
                timeoutMinutes=args.timeout,
                idleMinutes=args.idle,
                typingMin=typingMin,
                typingMax=typingMax,
            )
        )
        for i in range(args.count)
    ]

    logging.info(f"Launching {args.count} session(s) | typing delay {typingMin}-{typingMax}s...")
    await asyncio.gather(*tasks)


if __name__ == "__main__":
    asyncio.run(main())
