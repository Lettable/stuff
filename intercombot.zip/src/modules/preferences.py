import json
import random
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


def loadPreferences(path: str = "preference.json") -> list[dict]:
    """Load all preferences from preference.json."""
    file = Path(path)
    if not file.exists():
        raise FileNotFoundError(f"Preference file not found: {path}")
    with open(file, encoding="utf-8") as f:
        data = json.load(f)
    logger.info(f"Loaded {len(data)} preferences from {path}")
    return data


def pickRandom(preferences: list[dict]) -> tuple[str, str, list[str]]:
    """
    Pick a random preference and a random language that has content.
    Returns (slug, language, lines).
    """
    pref = random.choice(preferences)
    available = {
        lang: texts
        for lang, texts in pref["texts"].items()
        if texts
    }
    if not available:
        return pickRandom(preferences)

    language = random.choice(list(available.keys()))
    lines = [line for line in available[language] if line.strip()]
    return pref["slug"], language, lines
